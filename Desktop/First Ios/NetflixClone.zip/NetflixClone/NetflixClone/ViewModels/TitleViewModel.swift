//
//  TitleViewModel.swift
//  NetflixClone
//
//  Created by Ahmed Eslam on 20/02/2023.
//

import Foundation

struct TitleViewModel {
    let titleName : String
    let posterURL : String
}
