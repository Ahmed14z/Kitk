//
//  TtilePreviewViewModel.swift
//  NetflixClone
//
//  Created by Ahmed Eslam on 25/02/2023.
//

import Foundation


struct TitlePreviewViewodel {
    let title : String
    let youtubeView : VideoElement
    let titleOverView : String
}
